var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/ghl-form-webhook.ts
var ghl_form_webhook_exports = {};
__export(ghl_form_webhook_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(ghl_form_webhook_exports);
var GHL_BASE = "https://services.leadconnectorhq.com";
var GHL_VERSION = "2021-07-28";
var ok = (body) => ({
  statusCode: 200,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body)
});
function pick(data, ...keys) {
  if (!data) return void 0;
  for (const k of keys) {
    const v = data[k];
    if (v && String(v).trim()) return String(v).trim();
  }
  return void 0;
}
function buildTags(formName, data) {
  const tags = /* @__PURE__ */ new Set(["web-lead"]);
  const gclid = pick(data, "gclid");
  if (gclid) {
    tags.add("google-ads");
    tags.add("paid-traffic");
  }
  if (formName.includes("water-heater")) {
    tags.add("water-heater-lead");
  }
  const city = pick(data, "city");
  if (city && /chico/i.test(city)) tags.add("chico-lead");
  tags.add(gclid ? "warm-lead" : "cold-lead");
  return Array.from(tags);
}
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return ok({ skipped: "non-POST" });
  }
  const locationId = process.env.GHL_LOCATION_ID;
  const pit = process.env.GHL_LOCATION_PIT;
  if (!locationId || !pit) {
    console.error("[ghl-form-webhook] missing env: GHL_LOCATION_ID or GHL_LOCATION_PIT");
    return ok({ ok: false, error: "server misconfigured" });
  }
  let submission;
  try {
    submission = JSON.parse(event.body || "{}");
  } catch (e) {
    console.warn("[ghl-form-webhook] invalid JSON body", e);
    return ok({ ok: false, error: "invalid JSON" });
  }
  const formName = submission.form_name || "unknown-form";
  const data = submission.data || {};
  const phone = pick(data, "phone", "phone_number");
  if (!phone) {
    console.warn(`[ghl-form-webhook] no phone in submission ${submission.id} from form ${formName}`);
    return ok({ ok: false, error: "no phone in submission", formName });
  }
  const email = pick(data, "email");
  const firstName = pick(data, "first_name", "firstName") || pick(data, "name", "full_name", "fullName")?.split(/\s+/)[0] || void 0;
  const lastName = pick(data, "last_name", "lastName") || pick(data, "name", "full_name", "fullName")?.split(/\s+/).slice(1).join(" ") || void 0;
  const city = pick(data, "city");
  const situation = pick(data, "situation");
  const notes = pick(data, "notes", "message");
  const gclid = pick(data, "gclid");
  const utm_source = pick(data, "utm_source");
  const utm_medium = pick(data, "utm_medium");
  const utm_campaign = pick(data, "utm_campaign");
  const ad_group = pick(data, "ad_group", "utm_term");
  const keyword = pick(data, "keyword", "kw");
  const landing_page_url = pick(data, "landing_page_url") || `https://watkinsplumbing.net/water-heater-quote`;
  const tags = buildTags(formName, data);
  const customFields = [];
  if (situation) customFields.push({ key: "service_interest", field_value: situation });
  customFields.push({ key: "lead_source", field_value: gclid ? "Google" : "Website" });
  if (gclid) customFields.push({ key: "gclid", field_value: gclid });
  if (utm_source) customFields.push({ key: "utm_source", field_value: utm_source });
  if (utm_medium) customFields.push({ key: "utm_medium", field_value: utm_medium });
  if (utm_campaign) customFields.push({ key: "campaign_source", field_value: utm_campaign });
  if (ad_group) customFields.push({ key: "ad_group", field_value: ad_group });
  if (keyword) customFields.push({ key: "keyword", field_value: keyword });
  customFields.push({ key: "landing_page_url", field_value: landing_page_url });
  const ghlBody = {
    locationId,
    phone,
    tags,
    source: `Web \u2014 ${formName}`,
    customFields
  };
  if (email) ghlBody.email = email;
  if (firstName) ghlBody.firstName = firstName;
  if (lastName) ghlBody.lastName = lastName;
  if (city) ghlBody.city = city;
  try {
    const res = await fetch(`${GHL_BASE}/contacts/upsert`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${pit}`,
        Version: GHL_VERSION,
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify(ghlBody)
    });
    if (!res.ok) {
      const text = await res.text();
      console.error(
        `[ghl-form-webhook] GHL upsert failed for ${phone} from ${formName}: ${res.status} ${text}`
      );
      return ok({ ok: false, status: res.status, formName, phone });
    }
    const json = await res.json();
    const noteBody = [
      situation ? `Situation: ${situation}` : "",
      notes ? `Notes: ${notes}` : "",
      city ? `City: ${city}` : "",
      gclid ? `Google Ads click (gclid: ${gclid.substring(0, 12)}\u2026)` : ""
    ].filter(Boolean).join("\n");
    if (noteBody && json.contact?.id) {
      try {
        await fetch(`${GHL_BASE}/contacts/${json.contact.id}/notes`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${pit}`,
            Version: GHL_VERSION,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ body: noteBody, userId: "" })
        });
      } catch (e) {
        console.warn(`[ghl-form-webhook] note attach failed for ${phone}:`, e);
      }
    }
    const pipelineId = process.env.GHL_PIPELINE_ID;
    const stageNewId = process.env.GHL_PIPELINE_STAGE_NEW;
    let opportunityId = null;
    if (pipelineId && stageNewId && json.contact?.id) {
      try {
        const oppName = [
          firstName || phone,
          situation ? `\u2014 ${situation}` : "\u2014 Water Heater",
          city ? `(${city})` : ""
        ].filter(Boolean).join(" ").trim();
        const oppRes = await fetch(`${GHL_BASE}/opportunities/`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${pit}`,
            Version: GHL_VERSION,
            "Content-Type": "application/json",
            Accept: "application/json"
          },
          body: JSON.stringify({
            locationId,
            pipelineId,
            pipelineStageId: stageNewId,
            name: oppName.substring(0, 100),
            status: "open",
            contactId: json.contact.id,
            source: gclid ? "Google Ads" : "Website Form"
          })
        });
        if (oppRes.ok) {
          const oppJson = await oppRes.json();
          opportunityId = oppJson.opportunity?.id || null;
        } else {
          console.warn(
            `[ghl-form-webhook] opportunity create failed for ${phone}: ${oppRes.status} ${await oppRes.text()}`
          );
        }
      } catch (e) {
        console.warn(`[ghl-form-webhook] opportunity create exception for ${phone}:`, e);
      }
    }
    console.log(
      `[ghl-form-webhook] upserted phone=${phone} contactId=${json.contact?.id} oppId=${opportunityId} form=${formName} new=${json.new ?? false} tags=${tags.join(",")}`
    );
    return ok({
      ok: true,
      contactId: json.contact?.id,
      opportunityId,
      isNew: json.new ?? null,
      formName,
      tags
    });
  } catch (e) {
    console.error(`[ghl-form-webhook] exception for ${phone}:`, e);
    return ok({ ok: false, error: String(e) });
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
